package edu.cmu.cs.cs654.store;

import java.util.*;

/**
 * ShoppingCart interface from the book "Pragmatic Unit Testing."
 * @author A. Hunt, D. Thomas
 *
 */
public interface IShoppingCart {
	
	/**
	 * Add this many of the item to the shopping cart.
	 * @param anItem
	 * @param quantity
	 * @throws NegativeCountException
	 */
	public void addItems(IItem anItem, int quantity)
		throws NegativeCountException;
	
	/**
	 * Delete this many of this item from the shopping cart.
	 * @param anItem
	 * @param quantity
	 * @throws NegativeCountException
	 * @throws NoSuchItemException
	 */
	public void deleteItems(IItem anItem, int quantity)
		throws NegativeCountException, NoSuchItemException;

	/**
	 * Count all of the items in the cart
	 * (that is, all items times qty each)
	 * @return
	 */
	public int itemCount();
	
	/**
	 * Return Iterator of all items
	 * (see Java Collection's doc)
	 * @return
	 */
	public Iterator iterator();
}
