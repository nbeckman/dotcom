package edu.cmu.cs.cs654.store;

public interface IItem {

}
