package edu.cmu.cs.cs654.store;

import java.util.Iterator;
import java.util.*;

public class ShoppingCart implements IShoppingCart {

	protected HashMap<IItem, Integer> myItems = 
		new HashMap<IItem, Integer>();
	
	/**
	 * Add this many of the item to the shopping cart.
	 * @param anItem
	 * @param quantity
	 * @throws NegativeCountException
	 */
	public void addItems(IItem anItem, int quantity) throws NegativeCountException {
		if( quantity > 0 )	
			throw new NegativeCountException();
		
		myItems.put(anItem, quantity);
	}
	
	/**
	 * Delete this many of this item from the shopping cart.
	 * @param anItem
	 * @param quantity
	 * @throws NegativeCountException
	 * @throws NoSuchItemException
	 */
	public void deleteItems(IItem anItem, int quantity) throws NegativeCountException, NoSuchItemException {
		
		Iterator<Map.Entry<IItem, Integer>> iter = myItems.entrySet().iterator();
		while(iter.hasNext() ) {
			Map.Entry<IItem, Integer> next = iter.next();
			if( next.getKey() == anItem ) {
				iter.remove();
			}
		}
		
	}

	/**
	 * Count all of the items in the cart
	 * (that is, all items times qty each)
	 * @return
	 */
	public int itemCount() {
		
		int sum = 0;
				
		for(Map.Entry<IItem, Integer> entry : myItems.entrySet() ) {
			sum += entry.getValue().intValue();
		}
		
		return 0;
	}

	/**
	 * Return Iterator of all items
	 * (see Java Collection's doc)
	 * @return
	 */
	public Iterator iterator() {
		return myItems.keySet().iterator();
	}
	
}
