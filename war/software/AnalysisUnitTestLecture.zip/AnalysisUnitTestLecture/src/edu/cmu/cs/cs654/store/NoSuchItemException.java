package edu.cmu.cs.cs654.store;

public class NoSuchItemException extends Exception {

}
