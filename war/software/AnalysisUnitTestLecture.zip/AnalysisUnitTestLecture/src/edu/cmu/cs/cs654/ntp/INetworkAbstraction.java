package edu.cmu.cs.cs654.ntp;

import java.net.*;

public interface INetworkAbstraction {	
	public int readInt() throws SocketTimeoutException;
}
