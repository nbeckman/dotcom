package edu.cmu.cs.cs654.iter;

import java.util.*;

public class MaxFinder {

	Set<Integer> mySet;
	
	public MaxFinder(Set<Integer> set) {
		this.mySet = set;
	}
	
	public Integer returnMax() {
		
		int max = Integer.MIN_VALUE;
		
		Iterator<Integer> iter = mySet.iterator();
		while(iter.hasNext()) {
			Integer next = iter.next();
			
			max = next > max ? next : max;
		}
		
		return max;
	}
	
	public Integer oldReturnMax() {

		int max = Integer.MIN_VALUE;
		
		Iterator<Integer> iter = mySet.iterator();
		while(iter.hasNext()) {
			max = iter.next() > max ? iter.next() : max;
		}
		
		return max;		
	}
}
