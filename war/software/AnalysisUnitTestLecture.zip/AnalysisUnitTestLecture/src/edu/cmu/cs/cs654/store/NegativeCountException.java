package edu.cmu.cs.cs654.store;

public class NegativeCountException extends Exception {

}
