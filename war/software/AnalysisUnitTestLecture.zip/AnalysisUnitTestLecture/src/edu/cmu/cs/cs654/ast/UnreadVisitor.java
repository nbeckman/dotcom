package edu.cmu.cs.cs654.ast;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.*;

import java.util.*;

public class UnreadVisitor extends DescendingVisitor {

	protected Set<IVariableBinding> read = 
		new HashSet<IVariableBinding>();
	
	public Set<IVariableBinding> getReadVariables() {
		return read;
	}
	
	
	@Override
	public Object visit(IVariableUseExpressionNode n) {
	
		/*
		 * If my parent is an assignment and I am on the right-hand side,
		 * add this as a read variable.
		 */
		if( n.getParent().getNodeType() == NodeType.ASSIGN_EXPR &&
				((IAssignExpressionNode)n.getParent()).getOp2() == n) {
			
			
			read.add(n.resolveBinding());
		}
		
		return super.visit(n);
	}
}
