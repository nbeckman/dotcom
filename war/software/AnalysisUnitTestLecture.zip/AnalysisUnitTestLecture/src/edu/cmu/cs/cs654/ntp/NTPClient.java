package edu.cmu.cs.cs654.ntp;

import java.net.*;
import javax.net.*;
import java.io.*;

/**
 * This is a fake client of the network time protocol.
 * 
 * @author nbeckman
 *
 */
public class NTPClient {

	protected Socket mySocket;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		NTPClient ping = new NTPClient();
		
		try {
			ping.run(args[0], args[1]);
		} catch(Exception e) {
			System.out.println("Something didn't work.\n\n"+e);
		}
	}

	public INetworkAbstraction setupConnection(String host, String port) throws java.io.IOException {
		SocketFactory factory = SocketFactory.getDefault();
		
		mySocket = factory.createSocket(host, Integer.parseInt(port));
		mySocket.setSoTimeout(2000);
		
		/*
		 * This obviously is a quick and dirty hack...
		 */
		return new INetworkAbstraction() {
			public int readInt() {return (new java.util.Random()).nextInt();}
		};
	}
	
	public void run(String host, String port) throws java.io.IOException {
		
		INetworkAbstraction the_net = setupConnection(host, port);
		
		/*
		 * Send signal to server, wait for response, etc.
		 * Ellided here.
		 */	
		
		int time = readTimeFromStream(the_net);
		printTime(time);
	}
	
	/**
	 * This method should take the first byte sent back from the Server and interpret
	 * this as the time in milliseconds. Sometimes the connection may timeout. We should
	 * be aware of this problem.
	 * @param stream
	 * @return
	 * @throws IOException
	 */
	public static int readTimeFromStream(INetworkAbstraction stream) {
		
		int to_return = 0;
	
		try {
			to_return = stream.readInt();
		} catch(Exception e) {}
		
		return to_return;
	}
	
	public void printTime(int time) {
		System.out.println(time);
	}
}
