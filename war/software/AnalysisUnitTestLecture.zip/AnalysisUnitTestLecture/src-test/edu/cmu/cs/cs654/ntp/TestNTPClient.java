package edu.cmu.cs.cs654.ntp;

import static org.junit.Assert.*;
import org.junit.*;

import org.easymock.*;

import edu.cmu.cs.cs654.ntp.NTPClient;

import java.io.*;

public class TestNTPClient {
	
	@Test
	public void testReadTimeFromStream() throws IOException {
		
		INetworkAbstraction stream = 
			EasyMock.createMock(edu.cmu.cs.cs654.ntp.INetworkAbstraction.class);
		
		stream.readInt();		
		EasyMock.expectLastCall().andThrow(new java.net.SocketTimeoutException());
		
		EasyMock.replay(stream);
		int time = NTPClient.readTimeFromStream(stream);
		
		assertEquals(-1, time);
	}

}
