package edu.cmu.cs.cs654.ast;

import static org.junit.Assert.*;

import org.junit.*;

import com.surelogic.ast.java.operator.*;
import com.surelogic.ast.*;

import org.easymock.*;

public class TestUnreadVisitor {

	protected UnreadVisitor visitor;
	
	@Before
	public void setUp() {
		visitor = new UnreadVisitor();
	}

	@Test
	public void testVisitIVariableUseExpressionNode() {

		/*
		 * Set up mock object.
		 */
		IAssignExpressionNode parent = EasyMock.createMock(IAssignExpressionNode.class);
		IVariableBinding bind = EasyMock.createMock(IVariableBinding.class);
		IVariableUseExpressionNode use = EasyMock.createMock(IVariableUseExpressionNode.class);
		
		use.getParent();
		EasyMock.expectLastCall().andReturn(parent).anyTimes();
		
		parent.getNodeType();
		EasyMock.expectLastCall().andReturn(NodeType.ASSIGN_EXPR);
		
		parent.getOp2();
		EasyMock.expectLastCall().andReturn(use);
		
		use.resolveBinding();
		EasyMock.expectLastCall().andReturn(bind);
		
		/*
		 * Replay mode.
		 */
		EasyMock.replay(parent, bind, use);
		
		/*
		 * See that declaration has been added.
		 */
		visitor.visit(use);
		assertTrue(visitor.getReadVariables().contains(bind));
	}

}
