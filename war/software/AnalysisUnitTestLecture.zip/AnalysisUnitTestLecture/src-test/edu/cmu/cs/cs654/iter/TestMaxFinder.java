package edu.cmu.cs.cs654.iter;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Before;
import org.junit.Test;

import org.easymock.*;

public class TestMaxFinder {

	protected MaxFinder mf;
	
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testReturnMax() {
		
		Set<Integer> set = EasyMock.createMock(Set.class); 
		Iterator<Integer> iter = EasyMock.createStrictMock(Iterator.class);
		
		/*
		 * Return two elements, and then be empty.
		 */
		EasyMock.expect(set.iterator()).andReturn(iter);
		EasyMock.expect(iter.hasNext()).andReturn(true);
		EasyMock.expect(iter.next()).andReturn(new Integer(18));
		EasyMock.expect(iter.hasNext()).andReturn(true);
		EasyMock.expect(iter.next()).andReturn(new Integer(4));
		EasyMock.expect(iter.hasNext()).andReturn(false);
		
		EasyMock.replay(set, iter);
		
		mf = new MaxFinder(set);
		
		assertEquals(18, mf.returnMax().intValue());
	}

}
