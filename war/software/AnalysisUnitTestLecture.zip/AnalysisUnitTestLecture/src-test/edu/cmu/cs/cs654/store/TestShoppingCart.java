package edu.cmu.cs.cs654.store;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import edu.cmu.cs.cs654.store.IItem;
import edu.cmu.cs.cs654.store.NegativeCountException;
import edu.cmu.cs.cs654.store.ShoppingCart;

public class TestShoppingCart {

	class Item implements IItem {}
	
	public ShoppingCart mySC; 
	
	@Before
	public void setUp() throws Exception {
		mySC = new ShoppingCart();
	}

	@Test
	public void testAddItems() throws NegativeCountException {
		Item shoe = new Item();
		
		mySC.addItems(shoe, 0);
		assertTrue(mySC.itemCount() == 0);
	}
	
	@Test
	public void testAddItems2() throws NegativeCountException {
		Item sock = new Item();
		
		mySC.addItems(sock, 5);
		assertEquals(5, mySC.itemCount());
	}

	@Test
	public void testAddItems3() {
		
		Item pants = new Item();
		
		try {
			mySC.addItems(pants, -15);
			fail("This should have thrown an exception.");
		}
		catch (NegativeCountException nce) {
			assertTrue(true);
		}
		
		
	}

	@Test(expected= NegativeCountException.class)
	public void testAddItem4() throws NegativeCountException {
		Item pants = new Item();
		
		mySC.addItems(pants, -15);
	}
}
