Relentless Parallelizer
by Nels Beckman
www.cs.cmu.edu/~nbeckman/

REQUIREMENTS
-This plugin has only been tested on Eclipse 3.2 (and more
specifically, 3.2.1). However, it uses nothing special, and
should work for all later versions, and many earlier ones.

INSTALL
-There's not much to it. Just put the .jar file into the plugins
directory inside your Eclipse directory. That should do it. You
can verify by checking "Help|About Eclipse SDK|Plug-in Details"
once you start up Eclipse.

USING
-Again, not much to it. Right click on a Class with a main() method
in either the Package Explorer or the Outline views. Look for the
"Relentless Parallelism" sub-menu. Step back. Wait for the magic
to happen. Your code is now Relentlessly Parallel.
