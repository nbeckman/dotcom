package project;

import edu.cmu.cs.plural.annot.ResultUnique;
import sql.SQLQuery;

public class Browser {

	@ResultUnique(ensures="Tainted")
	static SQLQuery getUserQuery() {
		return null;
	}
	
}
