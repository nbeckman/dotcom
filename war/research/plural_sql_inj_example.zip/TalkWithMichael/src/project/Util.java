package project;

import edu.cmu.cs.plural.annot.ResultUnique;
import sql.SQLQuery;

public class Util {

	@ResultUnique(ensures="Untainted")
	public static SQLQuery scrub(SQLQuery query) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
