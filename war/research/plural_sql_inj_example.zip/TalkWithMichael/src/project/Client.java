package project;

import db.Database;
import db.Result;
import sql.CheckoutQuery;
import sql.PreparedStatement;
import sql.SQLQuery;

public class Client {

	String buggy() {
		SQLQuery query = Browser.getUserQuery();
		Result r = Database.makeQuery(query);
		return r.getValue();
	}
	
	String correct() {
		SQLQuery query = Browser.getUserQuery();
		query = Util.scrub(query);
		Result r = Database.makeQuery(query);
		return r.getValue();
	}
	
	String correct2() {
		PreparedStatement ps = new CheckoutQuery();
			
		Result r = Database.makePreparedQuery(ps);
		return r.getValue();
	}
	
}
