package db;

public class Result {

	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
