package db;


import edu.cmu.cs.plural.annot.Unique;
import sql.PreparedStatement;
import sql.SQLQuery;

public class Database {

	
	public static Result makeQuery(@Unique(requires="Untainted") SQLQuery query) {
		return null;
	}
	
	public static Result makePreparedQuery(@Unique PreparedStatement query) {
		return null;
	}
}
