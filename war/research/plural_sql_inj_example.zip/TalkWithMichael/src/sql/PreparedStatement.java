package sql;

public interface PreparedStatement extends SQLQuery {

}
