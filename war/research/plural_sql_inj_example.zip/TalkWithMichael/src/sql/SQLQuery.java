package sql;

public interface SQLQuery {

	String getText();
	
}
