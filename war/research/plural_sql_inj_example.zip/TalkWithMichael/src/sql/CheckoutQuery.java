package sql;

import edu.cmu.cs.plural.annot.Perm;


public class CheckoutQuery implements PreparedStatement {

	@Perm(ensures="unique(this!fr)")
	public CheckoutQuery() {
		
	}
	
	@Override
	public String getText() {
		// TODO Auto-generated method stub
		return null;
	}

}
