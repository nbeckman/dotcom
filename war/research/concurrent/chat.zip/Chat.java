
import javax.swing.JFrame;

/**
 * Runs a program that opens a "simple network chat" window that
 * supports two-way connections.
 */
public class Chat {
	
	/**
	 * Main program just creates a JFrame that shows a ChatPanel,
	 * and makes that window visible on the screen.
	 */
	public static void main(String[] args) {
		JFrame window = new JFrame("Simple Network Chat");
		window.setContentPane( new ChatPanel() );
		window.pack();
		window.setLocation(100,50);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}

}

