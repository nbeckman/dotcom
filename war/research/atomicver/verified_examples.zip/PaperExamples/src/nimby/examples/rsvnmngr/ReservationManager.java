package nimby.examples.rsvnmngr;

/*
 * This is my second version of the reservation manager from the paper.
 * It uses a better permission architecture.
 */

import edu.cmu.cs.plural.annot.*;

@ClassStates(@State(name="alive",
		invs={@Inv(field="rsvnDatabase", state="alive", perm=Inv.PermType.Unique)}))
class RsvnManager {
	private ReservationDatabase rsvnDatabase;

	@Share
	@Unique(var="result")
	Itinerary upgradeIfAvailable(@Unique(requires="byLand") Itinerary old_itin,
			@Share Flight desired_flight,
			int cust_id) {
		atomic: {			
			ReservationDatabase rdb = rsvnDatabase;
			this.rsvnDatabase = null;
			
			if( rdb.isHighDemand() && desired_flight.seatAvail() ) {
				FlightRsvn new_flight = rdb.reserveSeatH(desired_flight, cust_id);
				BusRsvn old_bus = old_itin.getConfirmedBusRsvn();
				rdb.relinquish(old_bus);
				old_itin.makeByAir(new_flight);
				
				this.rsvnDatabase = rdb;
				rdb = null;
				return old_itin;
			}
			else {
				return old_itin;
			}
		}
	}
}

/*
 * It's not over yet.
 */
@ClassStates({
	@State(name="alive", invs={@Inv(field="myFlightRsvn", perm=Inv.PermType.Full),
			                   @Inv(field="myBusRsvn", perm=Inv.PermType.Full)}),
	@State(name="byAir", 
invs={@Inv(field="myFlightRsvn", state="confirmed", stateOnly=true),
	  @Inv(field="myBusRsvn", isNull=Inv.Nullness.MustBeNull, stateOnly=true)}),
	          @State(name="byLand",
invs={@Inv(field="myBusRsvn", state="confirmed", stateOnly=true),
	  @Inv(field="myFlightRsvn", isNull=Inv.Nullness.MustBeNull, stateOnly=true)}),
	          @State(name="canceled",
invs={@Inv(field="myFlightRsvn", isNull=Inv.Nullness.MustBeNull, stateOnly=true),
	  @Inv(field="myBusRsvn", isNull=Inv.Nullness.MustBeNull, stateOnly=true)})})
class Itinerary {
	
	@Unique(requires="byLand", ensures="canceled")
	@Full(var="result", ensures="confirmed")
	BusRsvn getConfirmedBusRsvn() {
		atomic: {
			BusRsvn r = this.myBusRsvn;
			this.myBusRsvn = null;
			return r;
		}
	}
	
	@Imm
	void emailReminder() {
		if( myFlightRsvn.isConfirmed() ) {
			System.out.println("Reminder, Flight: " + myFlightRsvn.toString() );
		}
		else if( myBusRsvn.isConfirmed() ) {
			System.out.println("Reminder, Bus: " + myFlightRsvn.toString() );
		}
		return;
	}
	
	@Unique
	public Itinerary() {
		
	}
	
	FlightRsvn myFlightRsvn;
	BusRsvn myBusRsvn;
		
	@Unique(ensures="byAir")
	void makeByAir(@Unique(requires="confirmed", returned=false) FlightRsvn new_flight) {
		this.myBusRsvn = null;
		this.myFlightRsvn = new_flight;
		return;
	}
}

class Flight {
	
	@Unique
	public Flight() {
		
	}
	
	@Pure
	@StateTest({@Indicates(bool=true,state="seatAvail"),
		        @Indicates(bool=false,state="filled")})
	boolean seatAvail() {
		return true;
	}
}

class FlightRsvn {

	@Unique
	public FlightRsvn() {
		
	}
	
	@Pure
	@StateTest({@Indicates(bool=true,state="confirmed"),
		        @Indicates(bool=false,state="void")})
	boolean isConfirmed() {
		return true;
	}
	
	@Full(ensures="confirmed")
	void confirm() {}
}

class BusRsvn {

	@Unique
	public BusRsvn() {
		
	}
	
	@Pure
	@StateTest({@Indicates(bool=true,state="confirmed"),
		        @Indicates(bool=false,state="void")})
	boolean isConfirmed() {
		return true;
	}
	
	@Full(requires="confirmed", ensures="void")
	public void makeVoid() {
		return;
	}
	
}

class ReservationDatabase {

	@Imm
	@StateTest({@Indicates(bool=true,state="highBusDemand")})
	boolean isHighDemand() {
		return true;
	}
	
	@Full(requires="highBusDemand")
	void relinquish(@Full(requires="confirmed", ensures="void") BusRsvn myBusRsvn) {
		myBusRsvn.makeVoid();
		return;
	}
	
	@Full
	@Unique(var="result", ensures="confirmed")
	FlightRsvn reserveSeat(@Share(requires="seatAvail", ensures="alive") Flight f, int cid) {
		/*
		 * Dummy method.
		 */
		FlightRsvn result = new FlightRsvn();
		result.confirm();
		return result;
	}
	
	@Full(requires="highBusDemand", ensures="highBusDemand")
	@Unique(var="result", ensures="confirmed")
	FlightRsvn reserveSeatH(@Share(requires="seatAvail", ensures="alive") Flight f, int cid) {
		/*
		 * Dummy method.
		 */
		FlightRsvn result = new FlightRsvn();
		result.confirm();
		return result;
	}	
}




