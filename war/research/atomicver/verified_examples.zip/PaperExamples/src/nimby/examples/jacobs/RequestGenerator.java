package nimby.examples.jacobs;

/*
 * This is a program that cannot be checked by the Jacobs approach.
 * It uses a state invariant that depends on a thread-shared object.
 */

import java.util.concurrent.ConcurrentLinkedQueue;

import edu.cmu.cs.plural.annot.ClassStates;
import edu.cmu.cs.plural.annot.Full;
import edu.cmu.cs.plural.annot.Indicates;
import edu.cmu.cs.plural.annot.Inv;
import edu.cmu.cs.plural.annot.Pure;
import edu.cmu.cs.plural.annot.State;
import edu.cmu.cs.plural.annot.StateTest;
import edu.cmu.cs.plural.annot.Unique;

@ClassStates({@State(name="IDLE", 
		invs={@Inv(field="requestPipe", state="closed", perm=Inv.PermType.Full)}),
		      @State(name="RUNNING",
		invs={@Inv(field="requestPipe", state="open", perm=Inv.PermType.Full)})})
public class RequestGenerator {

	private RequestPipe requestPipe = new RequestPipe();
	
	@Unique(requires="IDLE", ensures="RUNNING")
	void start() {
		this.requestPipe.open();
		
		(new Thread(new Handler(this.requestPipe))).start();
		(new Thread(new Handler(this.requestPipe))).start();
		
		return;
	}

	@Unique(requires="RUNNING", ensures="RUNNING")
	void send(String str) {
		this.requestPipe.send(str);
		return;
	}
	
	@Unique(requires="RUNNING", ensures="IDLE")
	void stop() {
		this.requestPipe.close();
		return;
	}
}

class Thread extends java.lang.Thread {
	@Unique
	public Thread(@Unique(returned=false) Runnable r) {
		super(r);
	}
	
	@Unique(returned=false)
	public void start() {
		this.start();
		return;
	}
}

@ClassStates(@State(name="alive", invs={@Inv(field="reqPipe", perm=Inv.PermType.Pure)}))
class Handler implements Runnable {
	
	private RequestPipe reqPipe;
	
	@Unique
	Handler(@Pure RequestPipe pipe) {
		this.reqPipe = pipe;
		return;
	}
	
	public void run() {
		for(;;) {
			atomic: {
				if( this.reqPipe.isOpen() ) {
					String s = this.reqPipe.get();
					if( s != null ) {
						System.out.println("Got the message: " + s);
					}
				}
				else {
					break;
				}
			}
		}
		return;
	}
}

class RequestPipe {
	
	private ConcurrentLinkedQueue<String> queue;
	
	@Pure()
	@StateTest({@Indicates(bool=true, state="open")})
	boolean isOpen() {
		return true;
	}
	
	@Full(requires="closed", ensures="open")
	void open() {
		atomic: {
			this.queue = new ConcurrentLinkedQueue<String>();
		}
		return;
	}
	
	@Full(requires="open", ensures="closed")
	void close() {
		atomic: {
			this.queue = null;
		}
		return;
	}
	
	@Full(requires="open", ensures="open")
	void send(String str) {
		atomic: {
			this.queue.add(str);
			return;
		}
	}
	
	@Pure(requires="open", ensures="open")
	String get() {
		atomic: {
			return this.queue.poll();
		}
	}
}