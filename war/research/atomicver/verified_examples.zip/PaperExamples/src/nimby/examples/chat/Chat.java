package nimby.examples.chat;

/*
 * Here is a pedagogical example. It is meant to be a program similar in architecture to
 * a chat application I saw on the Internet once.
 */

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import edu.cmu.cs.plural.annot.ClassStates;
import edu.cmu.cs.plural.annot.Indicates;
import edu.cmu.cs.plural.annot.Inv;
import edu.cmu.cs.plural.annot.Share;
import edu.cmu.cs.plural.annot.State;
import edu.cmu.cs.plural.annot.StateTest;
import edu.cmu.cs.plural.annot.Unique;

/*
 * Simulate the call-back thread from the network that can disconnect the device at
 * will.
 */
@ClassStates(@State(name="alive", invs={@Inv(field="myNetwork", perm=Inv.PermType.Share)}))
class NetworkListener implements Runnable {
	
	final private Connection myNetwork;
	
	@Unique public void run() {
		for( int i = 0; i < 3; i++ ) {
			try {
				Thread.sleep(1000);
				
				atomic: synchronized(Chat.class) {
					if( myNetwork.isConnected() ) {
						myNetwork.disconnect();
					}
				}
			} catch(Exception e) { 
				break;
			}
		}
		return;
	}
	
	@Unique
	NetworkListener(Connection myNetwork) {
		this.myNetwork = myNetwork;
	}
}

class BufferedWriter extends java.io.BufferedWriter {
	public @Unique BufferedWriter(FileWriter f) {
		super(f);
	}
}

@ClassStates({@State(name="alive", invs={@Inv(field="socket")}),
	          @State(name="IDLE", invs={@Inv(field="socket", stateOnly=true, isNull=Inv.Nullness.MustBeNull)}),
	          @State(name="CONNECTED", invs={@Inv(field="socket", stateOnly=true, isNull=Inv.Nullness.CantBeNull)})})
class Connection {
	private BufferedWriter socket = null;
	
	@Unique Connection() {
		
	}
	
	@Share(requires="CONNECTED", ensures="IDLE")
	void disconnect() throws IOException {
		atomic: synchronized(Chat.class) {
			socket.flush();
			socket.close();
			this.socket = null;
			return;
		}
	}
	
	@Share
	@StateTest({@Indicates(bool=true, state="IDLE")})
	public boolean isIdle() {
		atomic: synchronized(Chat.class) {
			if( this.socket == null ) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	@Share
	@StateTest({@Indicates(bool=true, state="CONNECTED")})
	public boolean isConnected() {
		atomic: synchronized(Chat.class)
		{
			if( this.socket != null ) {
				return true;
			}
			else {
				return false;
			}
		}
	}
	
	@Share(requires="CONNECTED", ensures="CONNECTED")
	void send(String txt) throws IOException {
		atomic: synchronized(Chat.class) {
			this.socket.write(txt + "\n");
			return;
		}
	}
	
	@Share(requires="IDLE", ensures="CONNECTED")
	void connect(String ip) throws IOException {
		atomic: synchronized(Chat.class) {
			this.socket = new BufferedWriter(new FileWriter("foo.out", true));
			return;
		}
	}
}

/*
 * Simulates random button presses on GUI buttons via a thread.
 */
@ClassStates(@State(name="alive", invs={@Inv(field="myNetwork", perm=Inv.PermType.Share)}))
class GUI implements Runnable {
	
	final private Connection myNetwork;
	
	@Unique
	GUI(Connection myNetwork) {
		this.myNetwork = myNetwork;
	}
	
	/*
	 * Simulate random button presses from the user on enabled buttons.
	 */
	@Unique	public void run() {
		Random r = new Random();
		try {
			for(int i = 0; i < 20; i++) {
				Thread.sleep(300);
				
				switch(r.nextInt(6)) {
				case 0:
					atomic: synchronized(Chat.class) {
						if( myNetwork.isIdle() ) {
							myNetwork.connect("fake.fake.fake.fake");
						}
					}
					break;
				case 1:
					atomic: synchronized(Chat.class) {
						if( myNetwork.isConnected() ) {
							myNetwork.disconnect();
						}
					}
					break;
				case 2:
				case 3:
				case 4:
				case 5:
					atomic: synchronized(Chat.class) {
						if( myNetwork.isConnected() ) {
							myNetwork.send("Yo dude let's talk?!");
						}
					}
					break;
				default:
					break;
				}
			} 
		} catch (Exception e) { 
			return; 
		}
		finally {
			atomic: synchronized(Chat.class) {
				if( myNetwork.isConnected() ) {
					try { myNetwork.disconnect(); } catch(Exception e) {}
				}
			}
		}
	}
}

public class Chat {
	
	public static void main(String[] args) {
		Connection net = new Connection();
		GUI chat_gui = new GUI(net);
		NetworkListener listener = new NetworkListener(net);
		
		(new Thread(chat_gui)).start();
		(new Thread(listener)).start();
	}
	
}